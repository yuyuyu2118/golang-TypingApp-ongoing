package myUtil

import (
	"os"
	"time"

	"github.com/faiface/beep"
	"github.com/faiface/beep/mp3"
	"github.com/faiface/beep/speaker"
)

var effectBuffer *beep.Buffer

func PlayTypeSound() {
	effectStream := beep.ResampleRatio(4, 1, effectBuffer.Streamer(0, effectBuffer.Len()))
	speaker.Play(beep.Seq(effectStream, beep.Callback(func() {
		// Nothing needed here as there's no Close method for effectStream
	})))
}

func LoadTypeSoundCache() (*os.File, beep.StreamSeekCloser) {
	f, err := os.Open("assets/BGM/type.mp3")
	if err != nil {
		panic(err)
	}
	defer f.Close()

	streamer, format, err := mp3.Decode(f)
	if err != nil {
		panic(err)
	}
	defer streamer.Close()

	effectBuffer = beep.NewBuffer(format)
	effectBuffer.Append(streamer)
	return f, streamer
}

func PlayBGM() (*beep.Ctrl, *os.File, beep.StreamSeekCloser) {
	f, err := os.Open("Slime2.mp3")
	if err != nil {
		panic(err)
	}

	streamer, format, err := mp3.Decode(f)
	if err != nil {
		panic(err)
	}

	speaker.Init(format.SampleRate, format.SampleRate.N(time.Second/10))
	ctrl := &beep.Ctrl{Streamer: streamer, Paused: true}
	speaker.Play(ctrl)

	return ctrl, f, streamer
}
